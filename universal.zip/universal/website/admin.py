from django.contrib import admin
from .models import General_info, Slider, About, Team, Project, Services, Post, Staff

admin.site.register(General_info)
admin.site.register(Slider)
admin.site.register(About)
admin.site.register(Team)
admin.site.register(Project)
admin.site.register(Services)
admin.site.register(Post)
admin.site.register(Staff)